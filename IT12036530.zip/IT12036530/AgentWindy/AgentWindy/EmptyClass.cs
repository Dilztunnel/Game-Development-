﻿using System;

namespace AgentWindy
{
	public class EmptyClass
	{
		public EmptyClass ()
		{
		}
	}
}

